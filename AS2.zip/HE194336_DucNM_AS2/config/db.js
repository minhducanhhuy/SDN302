const mongoose = require('mongoose');

const normalizeCollections = async () => {
    try {
        const db = mongoose.connection.db;

        // Ensure Book _ids are ObjectIds
        const stringBooks = await db.collection('books').find({ _id: { $type: 'string' } }).toArray();
        for (const b of stringBooks) {
            await db.collection('books').deleteOne({ _id: b._id });
            b._id = new mongoose.Types.ObjectId(b._id);
            if (b.createdAt) b.createdAt = new Date(b.createdAt);
            if (b.updatedAt) b.updatedAt = new Date(b.updatedAt);
            await db.collection('books').insertOne(b);
        }

        // Ensure Member _ids are ObjectIds
        const stringMembers = await db.collection('members').find({ _id: { $type: 'string' } }).toArray();
        for (const m of stringMembers) {
            await db.collection('members').deleteOne({ _id: m._id });
            m._id = new mongoose.Types.ObjectId(m._id);
            if (m.createdAt) m.createdAt = new Date(m.createdAt);
            if (m.updatedAt) m.updatedAt = new Date(m.updatedAt);
            await db.collection('members').insertOne(m);
        }

        // Ensure Loan _ids, member_id, and book_ids are ObjectIds
        const stringLoans = await db.collection('loans').find({
            $or: [
                { _id: { $type: 'string' } },
                { member_id: { $type: 'string' } },
                { 'items.book_id': { $type: 'string' } }
            ]
        }).toArray();
        for (const l of stringLoans) {
            await db.collection('loans').deleteOne({ _id: l._id });
            l._id = new mongoose.Types.ObjectId(l._id);
            l.member_id = new mongoose.Types.ObjectId(l.member_id);
            l.items = (l.items || []).map(it => ({
                book_id: new mongoose.Types.ObjectId(it.book_id),
                quantity: it.quantity
            }));
            if (l.borrowDate) l.borrowDate = new Date(l.borrowDate);
            if (l.dueDate) l.dueDate = new Date(l.dueDate);
            if (l.returnDate) l.returnDate = new Date(l.returnDate);
            if (l.createdAt) l.createdAt = new Date(l.createdAt);
            if (l.updatedAt) l.updatedAt = new Date(l.updatedAt);
            await db.collection('loans').insertOne(l);
        }
    } catch (error) {
        console.warn('Note: Could not run collection normalization:', error.message);
    }
};

const connectDB = async () => {
    if (!process.env.MONGO_URI) {
        throw new Error('MONGO_URI is not configured.');
    }

    await mongoose.connect(process.env.MONGO_URI);
    await normalizeCollections();
    console.log('MongoDB connected successfully.');
};

module.exports = connectDB;

