module.exports = require('./authRoutes');
